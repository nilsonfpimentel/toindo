/** Automatically generated file. DO NOT MODIFY */
package br.com.toindoapk;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}