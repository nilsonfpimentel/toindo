package br.com.toindoapk;


import com.facebook.widget.ProfilePictureView;

import android.support.v7.app.ActionBarActivity;
import android.support.v4.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;



public class CadastroActivity extends ActionBarActivity {
	
	protected static final String CATEGORIA = "MyApp_CadastroActivity";
	private String id;
	private String name;
	private String email;
	
	public void setUserId(String id){
		this.id=id;	
	}
	public String getUserId(){
		return this.id;
	}	
	private String getUserName() {
		return name;
	}
	private void setUserName(String name) {
		this.name = name;
	}
	private String getUserEmail() {
		return email;
	}
	private void setUserEmail(String email) {
		this.email = email;
	}	
	
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_cadastro);

		if (savedInstanceState == null) {
			getSupportFragmentManager().beginTransaction()
					.add(R.id.container, new PlaceholderFragment()).commit();
		}
		
		//Recuperando os paramatros
		
		Intent intent = getIntent();		
		
		if (intent != null){
			Bundle params = intent.getExtras();
			
			if (params != null){
				Log.i(CATEGORIA,"parametros foram diferentes de null!");
				
				//String id = params.getString("user_id");
				setUserId(params.getString("user_id"));
				Log.i(CATEGORIA, "ID na Tela Cadastro " + getUserId() );
								
				//String name = params.getString("user_name");
				setUserName(params.getString("user_name"));
				Log.i(CATEGORIA, "NAME na Tela Cadastro " + getUserName());
							
				//String email = params.getString("user_email");
				setUserEmail(params.getString("user_email"));
				Log.i(CATEGORIA,"EMAIL na Tela Cadastro " + getUserEmail());				
				
			}		
		}		
	}
	
	@Override
	public void onResume() {		
	    super.onResume();
	    
	    Log.i(CATEGORIA, ".onResume() chamado.");
	    
	   //Setters dos Textviews
	    
	    ProfilePictureView ppv = (ProfilePictureView) findViewById(R.id.fbImg);
	    ppv.setProfileId(getUserId());
		
		EditText edtxId = (EditText) findViewById(R.id.edtx_id);
		edtxId.setText(getUserId());
		
		EditText edtxNome = (EditText) findViewById(R.id.edtx_name);	
		edtxNome.setText(getUserName());	
		
		EditText edtxEmail = (EditText) findViewById(R.id.edtx_email);
		edtxEmail.setText(getUserEmail());
	    
		
	}
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.cadastro, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_cadastro,
					container, false);
			return rootView;
		}
	}

}
