package br.com.toindoapk;

public class Promocao {
	private String id;
	private String idParceiro;
	private byte[] imagem;
	private String dataValidade;
	private double precoAnterior;
	private double precoPromocional;
	private String descricao;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getIdParceiro() {
		return idParceiro;
	}
	public void setIdParceiro(String idParceiro) {
		this.idParceiro = idParceiro;
	}
	public byte[] getImagem() {
		return imagem;
	}
	public void setImagem(byte[] imagem) {
		this.imagem = imagem;
	}
	public String getDataValidade() {
		return dataValidade;
	}
	public void setDataValidade(String dataValidade) {
		this.dataValidade = dataValidade;
	}
	public double getPrecoAnterior() {
		return precoAnterior;
	}
	public void setPrecoAnterior(double precoAnterior) {
		this.precoAnterior = precoAnterior;
	}
	public double getPrecoPromocional() {
		return precoPromocional;
	}
	public void setPrecoPromocional(double precoPromocional) {
		this.precoPromocional = precoPromocional;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	

}
