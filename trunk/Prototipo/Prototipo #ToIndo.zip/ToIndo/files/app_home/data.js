﻿$axure.loadCurrentPage({
  "url":"app_home.html",
  "generationDate":new Date(1401150226443),
  "isCanvasEnabled":false,
  "variables":["OnLoadVariable",
"FileName"],
  "page":{
    "packageId":"da750261b86e4c1c93fc8c0d6517a24c",
    "type":"Axure:Page",
    "name":"App Home",
    "notes":{
},
    "style":{
      "baseStyle":"627587b6038d43cca051c114ac41ad32",
      "pageAlignment":"near",
      "fill":{
        "fillType":"solid",
        "color":0xFFFFFFFF},
      "image":null,
      "imageHorizontalAlignment":"near",
      "imageVerticalAlignment":"near",
      "imageRepeat":"auto",
      "favicon":null,
      "sketchFactor":"0",
      "colorStyle":"appliedColor",
      "fontName":"Applied Font",
      "borderWidth":"0"},
    "adaptiveStyles":{
},
    "interactionMap":{
},
    "diagram":{
      "objects":[]}},
  "masters":{
},
  "objectPaths":{
}});