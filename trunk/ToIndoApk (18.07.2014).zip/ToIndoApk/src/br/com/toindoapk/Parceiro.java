package br.com.toindoapk;

public class Parceiro {
	private String idParceiro;
	private String idFacebook;
	private String nome_parceiro;
	private String email_parceiro;
	private String logradouro;
	private String numero;
	private String bairro;
	private String cidade;
	private String estado;	
	private String cep;
	private String website;	
	private String telefone1;
	private String telefone2;
	private String coordenadas;
	
	
		
	public String getIdParceiro() {
		return idParceiro;
	}
	public void setIdParceiro(String idParceiro) {
		this.idParceiro = idParceiro;
	}
	public String getIdFacebook() {
		return idFacebook;
	}
	public void setIdFacebook(String idFacebook) {
		this.idFacebook = idFacebook;
	}
	public String getNomeParceiro() {
		return nome_parceiro;
	}
	public void setNomeParceiro(String nome_parceiro) {
		this.nome_parceiro = nome_parceiro;
	}
	public String getEmailParceiro() {
		return email_parceiro;
	}
	public void setEmailParceiro(String email_parceiro) {
		this.email_parceiro = email_parceiro;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getTelefone1() {
		return telefone1;
	}
	public void setTelefone1(String telefone1) {
		this.telefone1 = telefone1;
	}
	public String getTelefone2() {
		return telefone2;
	}
	public void setTelefone2(String telefone2) {
		this.telefone2 = telefone2;
	}
	
	public String getLogradouro() {
		return logradouro;
	}
	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}
	public String getBairro() {
		return bairro;
	}
	public void setBairro(String bairro) {
		this.bairro = bairro;
	}
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	public String getCep() {
		return cep;
	}
	public void setCep(String cep) {
		this.cep = cep;
	}
	public String getCoordenadas() {
		return coordenadas;
	}
	public void setCoordenadas(String coordenadas) {
		this.coordenadas = coordenadas;
	}



}
