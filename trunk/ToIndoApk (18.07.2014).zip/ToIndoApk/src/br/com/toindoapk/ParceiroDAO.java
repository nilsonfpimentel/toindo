package br.com.toindoapk;


import java.util.ArrayList;
import java.util.List;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class ParceiroDAO {
	
	private final static String TABLE = "estabelecimento";	
	private SQLiteDatabase database;
	private DatabaseHelper sqliteOpenHelper;
	
	public ParceiroDAO (Context context){
		sqliteOpenHelper = new DatabaseHelper(context);
		
	}
	
	public void open () throws SQLException {
		database = sqliteOpenHelper.getWritableDatabase ();
		 }

	public void close () {
		sqliteOpenHelper.close ();
		 }
	
	//INSERIR PARCEIRO NO BANCO_DE_DADOS
		public void insert(Parceiro parceiro) throws Exception {
			ContentValues values = new ContentValues();

			values.put("idFacebook", parceiro.getIdFacebook());
			values.put("nome_parceiro", parceiro.getNomeParceiro());
			values.put("email_parceiro", parceiro.getEmailParceiro());			
			values.put("logradouro", parceiro.getLogradouro());
			values.put("numero", parceiro.getNumero());
			values.put("bairro", parceiro.getBairro());			
			values.put("cidade", parceiro.getCidade());
			values.put("estado", parceiro.getEstado());
			values.put("cep", parceiro.getCep());
			values.put("website", parceiro.getWebsite());
			values.put("telefone1", parceiro.getTelefone1());
			values.put("telefone2", parceiro.getTelefone2());
			values.put("coordenadas", parceiro.getCoordenadas());
			
			database.insert(TABLE, null, values);	
						
		}
		
		public void update(Parceiro parceiro) throws Exception {
			ContentValues values = new ContentValues();
			
			values.put("idFacebook", parceiro.getIdFacebook());
			values.put("nome_parceiro", parceiro.getNomeParceiro());
			values.put("email_parceiro", parceiro.getEmailParceiro());			
			values.put("logradouro", parceiro.getLogradouro());
			values.put("numero", parceiro.getNumero());
			values.put("bairro", parceiro.getBairro());			
			values.put("cidade", parceiro.getCidade());
			values.put("estado", parceiro.getEstado());
			values.put("cep", parceiro.getCep());
			values.put("website", parceiro.getWebsite());
			values.put("telefone1", parceiro.getTelefone1());
			values.put("telefone2", parceiro.getTelefone2());
			values.put("coordenadas", parceiro.getCoordenadas());
			
			database.update(TABLE, values, "id = ?", new String[] { "" + parceiro.getIdParceiro() });
			
			
		}
		
		public Parceiro findById(Integer id) {

			String sql = "SELECT * FROM " + TABLE + " WHERE id = ?";
			String[] selectionArgs = new String[] { "" + id };
			Cursor cursor = database.rawQuery(sql, selectionArgs);
			cursor.moveToFirst();

			return montaParceiro(cursor);
		}
		
		public Parceiro montaParceiro(Cursor cursor) {
			if (cursor.getCount() == 0) {
				return null;
			}
			Integer id = cursor.getInt(cursor.getColumnIndex("_id"));
		
			String idFacebook = cursor.getString(cursor.getColumnIndex("idFabebook"));
			String nome_parceiro = cursor.getString(cursor.getColumnIndex("nome_parceiro"));
			String email_parceiro = cursor.getString(cursor.getColumnIndex("email_parceiro"));
			String logradouro = cursor.getString(cursor.getColumnIndex("logradouro"));
			String numero = cursor.getString(cursor.getColumnIndex("numero"));
			String bairro = cursor.getString(cursor.getColumnIndex("bairro"));
			String cidade = cursor.getString(cursor.getColumnIndex("cidade"));
			String estado = cursor.getString(cursor.getColumnIndex("estado"));			
			String cep = cursor.getString(cursor.getColumnIndex("cep"));
			String website = cursor.getString(cursor.getColumnIndex("website"));
			String telefone1 = cursor.getString(cursor.getColumnIndex("telefone1"));
			String telefone2 = cursor.getString(cursor.getColumnIndex("telefone2"));
			String coordenadas = cursor.getString(cursor.getColumnIndex("coordenadas"));		
			
			
			Parceiro parceiro = new Parceiro();
			parceiro.setIdParceiro(id.toString());
			parceiro.setIdFacebook(idFacebook);
			parceiro.setNomeParceiro(nome_parceiro);
			parceiro.setEmailParceiro(email_parceiro);
			parceiro.setLogradouro(logradouro);
			parceiro.setNumero(numero);
			parceiro.setBairro(bairro);
			parceiro.setCidade(cidade);			
			parceiro.setEstado(estado);			
			parceiro.setCep(cep);
			parceiro.setWebsite(website);
			parceiro.setTelefone1(telefone1);
			parceiro.setTelefone2(telefone2);
			parceiro.setCoordenadas(coordenadas);
			
			return parceiro;
		}
		
		public List<Parceiro> findAll() throws Exception {
			List<Parceiro> retorno = new ArrayList<Parceiro>();
			String sql = "SELECT * FROM " + TABLE;
			Cursor cursor = database.rawQuery(sql, null);
			cursor.moveToFirst();
			while (!cursor.isAfterLast()) {
				retorno.add(montaParceiro(cursor));
				cursor.moveToNext();
				}
			return retorno;
		}



}

