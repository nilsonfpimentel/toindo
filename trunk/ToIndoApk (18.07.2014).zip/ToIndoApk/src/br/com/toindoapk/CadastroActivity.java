package br.com.toindoapk;

import com.facebook.Session;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CadastroActivity extends Activity {
	
	protected static final String CATEGORIA = "MyApp_CadastroActivity";
	private android.app.ActionBar actionbar;
	private Parceiro parceiro;
	Button btnSalvar;
	Button btnVoltar;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_cadastro);
		
		getObjects();
		setObjects();
		getInfoLogin();	
		
		btnSalvar = (Button) findViewById(R.id.btnSalvar);
		btnVoltar = (Button) findViewById(R.id.btnVoltar);	
		
		
	}
	
	/**
	 * M�todo que Recupera Parametros do LoginFacebook
	 */
	public void getInfoLogin(){
		Intent intent = getIntent();
		parceiro = new Parceiro();
		
		if (intent != null){
			Bundle params = intent.getExtras();
			
			if (params != null){
						
				EditText Edit_Nome = (EditText) findViewById(R.id.editNomeEstabelecimento);
				EditText Edit_Email = (EditText) findViewById(R.id.editEmailEstabelecimento);
				
				
				//ProfilePictureView ppv = (ProfilePictureView) findViewById(R.id.fbImg);
				//ppv.setProfileId(id);
				
				parceiro.setIdFacebook(params.getString("user_id"));
				
				Log.i(CATEGORIA, "ID na Tela Cadastro " + parceiro.getIdFacebook());										
				
				parceiro.setNomeParceiro(params.getString("user_name"));
				Log.i(CATEGORIA, "NAME na Tela Cadastro " + parceiro.getNomeParceiro());							
				
				parceiro.setEmailParceiro(params.getString("user_email"));
				Log.i(CATEGORIA,"EMAIL na Tela Cadastro " + parceiro.getEmailParceiro());
				
				Edit_Nome.setText(parceiro.getNomeParceiro());
				Edit_Email.setText(parceiro.getEmailParceiro());
			}
			
		}		
	}
	
	/**
	 * Pega as informac�es do banco se o usuario ja for cadastrado e seta nos editexts
	 */
	
	public void getInfoFromBD(){
		final SQLiteDatabase db = openOrCreateDatabase("toindo.db", Context.MODE_PRIVATE, null);

		try {
			final Cursor cursor_parceiro = db.rawQuery("SELECT * FROM parceiro WHERE idFacebook = ?", new String[] {parceiro.getIdFacebook() });

			if (cursor_parceiro.moveToFirst()) {

				
				EditText edtxNome = (EditText) findViewById(R.id.editNomeEstabelecimento);
				EditText edtxEmail = (EditText) findViewById(R.id.editEmailEstabelecimento);
				EditText edtxLogradouro = (EditText) findViewById(R.id.editLogradouro);
				EditText edtxNumero = (EditText) findViewById(R.id.editNumero);
				EditText edtxBairro = (EditText) findViewById(R.id.editBairro);
				EditText edtxCidade = (EditText) findViewById(R.id.editCidade);
				EditText edtxEstado = (EditText) findViewById(R.id.editEstado);
				EditText edtxCep = (EditText) findViewById(R.id.editCep);				
				EditText edtxWebSite = (EditText) findViewById(R.id.editWebSite);
				EditText edtxTelefone1 = (EditText) findViewById(R.id.editTelefone1);
				EditText edtxTelefone2 = (EditText) findViewById(R.id.editTelefone2);
				
				
				edtxNome.setText(cursor_parceiro.getString(2));
				
				edtxEmail.setText(cursor_parceiro.getString(3));
				
				edtxLogradouro.setText(cursor_parceiro.getString(4));
				
				edtxNumero.setText(cursor_parceiro.getString(5));
				
				edtxBairro.setText(cursor_parceiro.getString(6));
				
				edtxCidade.setText(cursor_parceiro.getString(7));
				
				edtxEstado.setText(cursor_parceiro.getString(8));
				
				edtxCep.setText(cursor_parceiro.getString(9));
				
				edtxWebSite.setText(cursor_parceiro.getString(10));
				
				edtxTelefone1.setText(cursor_parceiro.getString(11));
				
				edtxTelefone2.setText(cursor_parceiro.getString(12));				

			}

		} catch (Exception ex) {

			EditText edtxNome = (EditText) findViewById(R.id.editNomeEstabelecimento);
			edtxNome.setText(parceiro.getNomeParceiro());
			
			EditText edtxEmail = (EditText) findViewById(R.id.editEmailEstabelecimento);
			edtxEmail.setText(parceiro.getEmailParceiro());			
		}
				
		db.close();////////////////////////

	}
	
	/**
	 * Pega o ActionBar
	 */
	public void getObjects(){		
		actionbar = getActionBar();
	}
	/**
	 * Ser�o setados o Icone, o Titulo e Trasformar� o logo em bot�o no ActionBar;
	 */
	public void setObjects(){
		actionbar.setIcon(R.drawable.logo_ac);
		actionbar.setTitle("");
		actionbar.setDisplayHomeAsUpEnabled(true);
		}	
	
	
	
	/**
	 * M�todo onClick do Bot�o Voltar (Retorna para Activity Anterior)
	 * @param view
	 */
	public void voltar(View view){
		if (Session.getActiveSession() !=null){
			Session.getActiveSession().closeAndClearTokenInformation();
			}
		Intent intent = new Intent(getApplicationContext(), MainActivity.class);
		startActivity(intent);
		finish();
		overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
	
	}
	
	public void confirmar(View view){
		
		
		final EditText edtxNomeEstabelecimento = (EditText) findViewById(R.id.editNomeEstabelecimento);	
	    
		
		final EditText edtxLogradouro = (EditText) findViewById(R.id.editLogradouro);
				
				
		final EditText edtxNumero = (EditText) findViewById(R.id.editNumero);
				
				
		final EditText edtxBairro = (EditText) findViewById(R.id.editBairro);
				
				
		final EditText edtxCidade = (EditText) findViewById(R.id.editCidade);
				
			
		final EditText edtxEstado = (EditText) findViewById(R.id.editEstado);
				
				
		final EditText edtxCep = (EditText) findViewById(R.id.editCep);
				
				
		final EditText edtxEmailEstabelecimento = (EditText) findViewById(R.id.editEmailEstabelecimento);
		
		final EditText edtxWebsite = (EditText) findViewById(R.id.editWebSite);
				
				
		final EditText edtxTel1 = (EditText) findViewById(R.id.editTelefone1);
		
		final EditText edtxTel2 = (EditText) findViewById(R.id.editTelefone2);
		
		
		if (edtxNomeEstabelecimento.getText().toString().length() <= 0){
    		edtxNomeEstabelecimento.setError("Insira um Nome!");
    		edtxNomeEstabelecimento.requestFocus();
    		}
		else if(edtxLogradouro.getText().toString().length() <= 0){
			edtxLogradouro.setError("Insira Um Logradouro!");
			edtxLogradouro.requestFocus(); 
			
		}
		
		else if(edtxNumero.getText().toString().length() <= 0){
			edtxNumero.setError("Insira Um Numero!");
			edtxNumero.requestFocus(); 
			
		}
		
		else if(edtxBairro.getText().toString().length() <= 0){
			edtxBairro.setError("Insira um Bairro!");
			edtxBairro.requestFocus(); 
			
		}
		else if(edtxCidade.getText().toString().length() <= 0){
			edtxCidade.setError("Insira uma Cidade!");
			edtxCidade.requestFocus(); 
			
		}

		else if(edtxEstado.getText().toString().length() != 2){
			edtxEstado.setError("Insira um Estado: Ex: PE");
			edtxEstado.requestFocus(); 
			
		}
				
		else if(edtxEmailEstabelecimento.getText().toString().length() <= 0){
			edtxEmailEstabelecimento.setError("Insira um Email!");
			edtxEmailEstabelecimento.requestFocus(); 					
		}
		
		else if(edtxTel1.getText().toString().length() <= 0){
			edtxTel1.setError("Insira um Telefone!");
			edtxTel1.requestFocus(); 
		}
		else{
			try{
				
				final SQLiteDatabase db = openOrCreateDatabase("toindo.db",Context.MODE_PRIVATE, null);
	    		
	    		ContentValues ctv = new ContentValues();
	    		
	    		ctv.put("idFacebook", parceiro.getIdFacebook());
	    		ctv.put("nome_estabelecimento",edtxNomeEstabelecimento.getText().toString()); 
	    		ctv.put("email", edtxEmailEstabelecimento.getText().toString());
	    		ctv.put("logradouro", edtxLogradouro.getText().toString());
	    		ctv.put("numero", edtxNumero.getText().toString());
	    		ctv.put("bairro", edtxBairro.getText().toString());
	    		ctv.put("cidade", edtxCidade.getText().toString());
	    		ctv.put("estado", edtxEstado.getText().toString());
	    		ctv.put("cep", edtxCep.getText().toString());	    		
	    		ctv.put("website", edtxWebsite.getText().toString());
	    		ctv.put("telefone1", edtxTel1.getText().toString());
	    		ctv.put("telefone2", edtxTel2.getText().toString());
	    	
	    		if(db.insert("parceiro", "_id", ctv) > 0){
	    			Toast.makeText(getBaseContext(), "Sucesso ao enviar", Toast.LENGTH_SHORT).show();
	    			Intent intent = new Intent(getApplicationContext(), ParceiroManagerActivity.class);
	    			startActivity(intent);
	    			finish();
	    			overridePendingTransition(android.R.anim.slide_in_left,	android.R.anim.slide_out_right);  			
	    			
	    		} else {
	    			Toast.makeText(getBaseContext(), "Erro ao enviar", Toast.LENGTH_SHORT).show();
	    			
	    		}
	    		db.close();
    		} catch(Exception ex){
    			Toast.makeText(getBaseContext(), ex.getMessage(), Toast.LENGTH_SHORT).show();
    			}
			}
		
		}
	
	
	@Override
	public void onResume() {		
	    super.onResume();
	    getInfoFromBD();
	    
	} 
	
	@Override
	public void onPause() {
		super.onPause();
		finish();
	    
	} 
	
	@Override
	public void onStop(){
		super.onStop();
		
		
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		this.finish();

	}
	
	/**
	 * M�todo que sobEscreve o bot�o voltar do Smartphone
	 */
	/*@Override
	public void onBackPressed() {
	    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
	    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
	    intent.putExtra("EXIT", true);
	    startActivity(intent);
	    
	    if (Session.getActiveSession() !=null){
			Session.getActiveSession().closeAndClearTokenInformation();;
			}
	}
	**/
	/**
	 * M�todo inicializam as op��es do Menu
	 */
	@Override
	public boolean onCreateOptionsMenu(Menu menu){
		super.onCreateOptionsMenu(menu);
		getMenuInflater().inflate(R.menu.cadastro, menu);
		
		return (true);
	}
	
	/**
	 * M�todo setam os icones e bot�es no ActionBar do Menu
	 */
	@Override
	public boolean onMenuItemSelected(int panel, MenuItem item){
		switch(item.getItemId()){
			case android.R.id.home:
				Log.i("script","ok");
				break;
			case R.id.exit:
				Log.i("script","Sair");
				if (Session.getActiveSession() !=null){
					Session.getActiveSession().closeAndClearTokenInformation();
					}
				Intent intent = new Intent(getApplicationContext(), MainActivity.class);
				startActivity(intent);
				
				finish();
				overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
				break;		
		}
		
		return (true);
	}
	
}