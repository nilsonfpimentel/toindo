package br.com.toindoapk;

import br.com.toindoapk.fragments.FragmentParceiro;
import br.com.toindoapk.fragments.FragmentUsuario;

import java.util.Arrays;
import java.util.List;
import java.util.Vector;

import com.facebook.Request;
import com.facebook.Response;
import com.facebook.Session;
import com.facebook.SessionState;
import com.facebook.UiLifecycleHelper;
import com.facebook.model.GraphUser;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.View;


public class MainActivity extends FragmentActivity {
	private UiLifecycleHelper uiHelper;
	private PagerAdapter mPagerAdapter;
	private List<Fragment> fragments; 
	private Bundle params = new Bundle();
	private ViewPager mViewPager;
	private ParceiroDAO parceiroDAO;
	
	private Session.StatusCallback callback = new Session.StatusCallback() {
		@Override
		public void call(Session session, SessionState state, Exception exception) {
			onSessionStateChanged(session, state, exception);
		}
	};
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.viewpager_layout);
		initialisePaging();
		
		uiHelper = new UiLifecycleHelper(this, callback);
		uiHelper.onCreate(savedInstanceState);
		
		parceiroDAO = new ParceiroDAO(this);
		parceiroDAO.open();
		
		//LoginButton lb = (LoginButton) findViewById(R.id.fb_login_button);
		//lb.setPublishPermissions(Arrays.asList("email", "public_profile", "user_friends"));
		
	}
	/**
	 * M�todo onClick do Bot�o LoginFacebook
	 * @param view
	 */
	public void loginFace(View view) {
	    Session session = Session.getActiveSession();
	    if (!session.isOpened() && !session.isClosed()) {
	        session.openForRead(new Session.OpenRequest(this)
	            .setPermissions(Arrays.asList("email", "public_profile", "user_friends"))
	            .setCallback(callback));
	    } else {
	    	Session.openActiveSession(this, true, callback);
	    }
	    Session.getActiveSession().getPermissions();
	    
	}
	
	/**
	 * M�todo de atua��o do ViewPager 
	 * (server para passar da fragment Usuario para fragment Parceiro)
	 */
	private void initialisePaging() {
		fragments = new Vector<Fragment>();
		fragments.add(Fragment.instantiate(getBaseContext(), FragmentUsuario.class.getName()));
		fragments.add(Fragment.instantiate(getBaseContext(), FragmentParceiro.class.getName()));
		mPagerAdapter = new PagerAdapter(this.getSupportFragmentManager(), fragments);
		
		mViewPager= (ViewPager) findViewById(R.id.viewpager);
		mViewPager.setAdapter(mPagerAdapter);
	}

	@Override
	public void onResume() {
		if (getIntent().getBooleanExtra("EXIT", false)) {
			finish();
		}
		super.onResume();
		Session session = Session.getActiveSession();
		if(session != null && (session.isClosed() || session.isOpened())){
			onSessionStateChanged(session, session.getState(), null);
		}
		
		uiHelper.onResume();
		parceiroDAO.open();
	}
	
	
	@Override
	public void onPause() {
		super.onPause();
		uiHelper.onPause();
		parceiroDAO.close();
	}
	
	@Override
	public void onStop(){
		super.onStop();
		uiHelper.onStop();
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		uiHelper.onDestroy();
	}
	
	
	@Override
	public void onSaveInstanceState(Bundle bundle) {
		super.onSaveInstanceState(bundle);
		uiHelper.onSaveInstanceState(bundle);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		uiHelper.onActivityResult(requestCode, resultCode, data);
	}
	
	// METHODS FACEBOOK
	/**
	 * Verificar se o usuario est� conectado ou n�o
	 * @param session
	 * @param state
	 * @param exception
	 */
	public void onSessionStateChanged(final Session session, SessionState state, Exception exception){
		if(session != null && session.isOpened()){
			
			Log.i("Script", "Usu�rio conectado1");
			
			if (fragments.get(0).getUserVisibleHint()){
				Log.i("Script", "Usuario Logado1");
				Intent intent = new Intent(getBaseContext(), OfertasActivity.class);
				startActivity(intent);
				finish();
				overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
			
			}
			else if (fragments.get(1).getUserVisibleHint()){
				Log.i("Script", "Parceiro Logado");
				
				getInformationMe(session);
				//getFriends(session);	
			}
		}
		else{
			Log.i("Script", "Usu�rio n�o conectado");
		}
	}
	
	/**
	 * Pegar Lista de Amigos do usuario
	 * @param session
	 
	public void getFriends(Session session){
		Request.newMyFriendsRequest(session, new Request.GraphUserListCallback() {
			@Override
			public void onCompleted(List<GraphUser> users, Response response) {
				if(users != null){
					Log.i("Script", "Friends: "+users.size());
				}
				Log.i("Script", "response: "+response);
			}
		}).executeAsync();
	}
	*/
	
	
	
	/**
	 * Verifica se o parceiro est� cadastrado no banco de dados
	 */
	public boolean isParceiroCadastrado(String idFBParceiro) throws Exception{
		final SQLiteDatabase db = openOrCreateDatabase("toindo.db", Context.MODE_PRIVATE, null);
		final Cursor cursor_parceiro = db.rawQuery("SELECT * FROM parceiro WHERE idFacebook = ?", new String[] {idFBParceiro});
		
		if (cursor_parceiro.moveToFirst()) {
			return true;
					
		}
		else{
			return false;			
			
		}
		
	}
	/**
	 * Pegar informa��es do Usuario/Parceiro logado
	 * @param session
	 */
	public void getInformationMe(Session session){
		Request.newMeRequest(session, new Request.GraphUserCallback() {
			@Override
			public void onCompleted(GraphUser user, Response response) {
				
				try {
					if(user != null & isParceiroCadastrado(user.getId()) ){	
									
						Intent intent = new Intent(getApplicationContext(), ParceiroManagerActivity.class);
						
						///
						params.putString("user_id", user.getId());	
						params.putString("user_name", user.getFirstName()+" "+user.getLastName());
						params.putString("user_email", user.getProperty("email").toString());						
						
						intent.putExtras(params);
		    			startActivity(intent);
		    			finish();
		    			////
		    			
					}
					else if (user != null & !isParceiroCadastrado(user.getId())){
												
						Intent intent = new Intent(getBaseContext(), CadastroActivity.class);

						params.putString("user_id", user.getId());	
						params.putString("user_name", user.getFirstName()+" "+user.getLastName());
						params.putString("user_email", user.getProperty("email").toString());						
						
						intent.putExtras(params);
						startActivity(intent);	
						overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
						finish();						
					}								
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}).executeAsync();
	}
}
